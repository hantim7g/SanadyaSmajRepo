package com.hst.payment.enums;

public enum PaymentProcessType {
    VIVA,
    ROOM_BOOKING,
    ADVERTISEMENT,
    MEMBERSHIP
}
