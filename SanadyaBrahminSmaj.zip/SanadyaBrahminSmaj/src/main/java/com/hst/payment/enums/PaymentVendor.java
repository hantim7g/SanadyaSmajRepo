package com.hst.payment.enums;

public enum PaymentVendor {
    RAZORPAY,
    PAYU,
    CASHFREE,
    PHONEPE,
    OFFLINE
}
