package com.hst.entity.BookingSys;

public enum PaymentMethod {
    UPI, CARD, NET_BANKING, CASH
}
