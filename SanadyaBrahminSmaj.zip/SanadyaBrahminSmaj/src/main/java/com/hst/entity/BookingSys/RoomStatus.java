package com.hst.entity.BookingSys;

public enum RoomStatus {
    AVAILABLE, BOOKED, CLEANING, MAINTENANCE, BLOCKED
}
