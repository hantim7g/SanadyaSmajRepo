package com.hst.entity.BookingSys;

public enum PaymentStatus {
    SUCCESS, FAILED, PENDING, REFUNDED
}