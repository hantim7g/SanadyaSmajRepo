package com.hst.entity.BookingSys;
public enum TaskStatus {
    ASSIGNED, IN_PROGRESS, COMPLETED
}
