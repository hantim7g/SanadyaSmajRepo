package com.hst.repository;

import com.hst.entity.RegistrationSequence;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistrationSequenceRepository extends JpaRepository<RegistrationSequence, Long> {
}
